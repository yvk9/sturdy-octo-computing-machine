variable "application" {
  description = "Application name used in CAF-style naming."
  type        = string
}

variable "workload" {
  description = "Workload name used in CAF-style naming."
  type        = string
}

variable "environment" {
  description = "Environment such as dev, test, uat or prod."
  type        = string

  validation {
    condition     = contains(["dev", "test", "uat", "prod"], lower(var.environment))
    error_message = "Environment must be dev, test, uat or prod."
  }
}

variable "instance" {
  description = "SQL Server instance number."
  type        = number
  default     = 1
}

variable "resource_group_name" {
  description = "Resource group containing the SQL Server."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "sql_version" {
  description = "Azure SQL logical server version."
  type        = string
  default     = "12.0"
}

variable "administrator_login" {
  description = "SQL administrator login. Prefer Azure AD-only authentication where possible."
  type        = string
  default     = null
}

variable "administrator_login_password" {
  description = "SQL administrator password."
  type        = string
  sensitive   = true
  default     = null
}

variable "minimum_tls_version" {
  description = "Minimum TLS version."
  type        = string
  default     = "1.2"
}

variable "connection_policy" {
  description = "SQL connection policy."
  type        = string
  default     = "Default"

  validation {
    condition     = contains(["Default", "Proxy", "Redirect"], var.connection_policy)
    error_message = "connection_policy must be Default, Proxy or Redirect."
  }
}

variable "public_network_access_enabled" {
  description = "Whether public network access is enabled."
  type        = bool
  default     = false
}

variable "outbound_network_restriction_enabled" {
  description = "Whether outbound network restriction is enabled."
  type        = bool
  default     = true
}

variable "managed_identity_type" {
  description = "Managed identity type."
  type        = string
  default     = "UserAssigned"

  validation {
    condition = contains(
      ["SystemAssigned", "UserAssigned", "SystemAssigned, UserAssigned"],
      var.managed_identity_type
    )
    error_message = "managed_identity_type is invalid."
  }
}

variable "managed_identity_ids" {
  description = "User-assigned managed identity resource IDs."
  type        = list(string)
  default     = []
}

variable "primary_user_assigned_identity_id" {
  description = "Primary user-assigned managed identity resource ID."
  type        = string
  default     = null
}

variable "azuread_administrator" {
  description = "Microsoft Entra ID administrator configuration."

  type = object({
    login_username              = string
    object_id                   = string
    tenant_id                   = optional(string)
    azuread_authentication_only = optional(bool, true)
  })

  default = null
}

variable "transparent_data_encryption_key_vault_key_id" {
  description = "Key Vault key ID used for TDE with customer-managed key."
  type        = string
  default     = null
}

variable "express_vulnerability_assessment_enabled" {
  description = "Enable Express Vulnerability Assessment."
  type        = bool
  default     = true
}


variable "private_endpoint_enabled" {
  description = "Whether to create a Private Endpoint."
  type        = bool
  default     = false
}

variable "private_endpoint_subnet_id" {
  description = "Subnet ID for the SQL Private Endpoint."
  type        = string
  default     = null
}

variable "private_dns_zone_ids" {
  description = "Private DNS Zone IDs to associate with the Private Endpoint."
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Common resource tags."
  type        = map(string)
  default     = {}
}
