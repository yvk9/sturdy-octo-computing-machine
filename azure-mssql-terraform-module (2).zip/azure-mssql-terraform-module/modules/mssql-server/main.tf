locals {
  # CAF-style example:
  # sql-<application>-<workload>-<environment>-<instance>
  server_name = lower(
    "sql-${var.application}-${var.workload}-${var.environment}-${format("%02d", var.instance)}"
  )

  common_tags = merge(
    {
      application = var.application
      workload    = var.workload
      environment = var.environment
      managed_by  = "terraform"
    },
    var.tags
  )
}

resource "azurerm_mssql_server" "this" {
  name                = local.server_name
  resource_group_name = var.resource_group_name
  location            = var.location
  version             = var.sql_version

  administrator_login          = var.administrator_login
  administrator_login_password = var.administrator_login_password

  minimum_tls_version = var.minimum_tls_version
  connection_policy   = var.connection_policy

  public_network_access_enabled        = var.public_network_access_enabled
  outbound_network_restriction_enabled = var.outbound_network_restriction_enabled

  dynamic "identity" {
    for_each = var.managed_identity_type != null ? [1] : []

    content {
      type         = var.managed_identity_type
      identity_ids = var.managed_identity_ids
    }
  }

  primary_user_assigned_identity_id = var.primary_user_assigned_identity_id

  dynamic "azuread_administrator" {
    for_each = var.azuread_administrator != null ? [var.azuread_administrator] : []

    content {
      login_username              = azuread_administrator.value.login_username
      object_id                   = azuread_administrator.value.object_id
      tenant_id                   = try(azuread_administrator.value.tenant_id, null)
      azuread_authentication_only = try(azuread_administrator.value.azuread_authentication_only, true)
    }
  }

  transparent_data_encryption_key_vault_key_id = var.transparent_data_encryption_key_vault_key_id

  express_vulnerability_assessment_enabled = var.express_vulnerability_assessment_enabled

  tags = local.common_tags

  lifecycle {
    precondition {
      condition = (
        var.transparent_data_encryption_key_vault_key_id == null ||
        var.managed_identity_type != null
      )
      error_message = "TDE with a customer-managed key requires a managed identity."
    }
  }
}

resource "azurerm_private_endpoint" "sql" {
  count = var.private_endpoint_enabled ? 1 : 0

  name                = "${local.server_name}-pe"
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.private_endpoint_subnet_id

  private_service_connection {
    name                           = "${local.server_name}-private-connection"
    private_connection_resource_id = azurerm_mssql_server.this.id
    is_manual_connection           = false
    subresource_names              = ["sqlServer"]
  }

  dynamic "private_dns_zone_group" {
    for_each = length(var.private_dns_zone_ids) > 0 ? [1] : []

    content {
      name                 = "default"
      private_dns_zone_ids = var.private_dns_zone_ids
    }
  }

  tags = local.common_tags
}
