output "server_id" {
  description = "Azure SQL Server resource ID."
  value       = azurerm_mssql_server.this.id
}

output "server_name" {
  description = "Azure SQL Server name."
  value       = azurerm_mssql_server.this.name
}

output "fully_qualified_domain_name" {
  description = "Azure SQL Server FQDN."
  value       = azurerm_mssql_server.this.fully_qualified_domain_name
}

output "identity_principal_id" {
  description = "SQL Server managed identity principal ID."
  value       = try(azurerm_mssql_server.this.identity[0].principal_id, null)
}

output "private_endpoint_id" {
  description = "SQL Private Endpoint resource ID."
  value       = try(azurerm_private_endpoint.sql[0].id, null)
}
