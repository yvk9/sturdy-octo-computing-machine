terraform {
  required_version = ">= 1.6.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.0, < 6.0"
    }
  }
}

provider "azurerm" {
  features {}
}

module "mssql_server" {
  source = "../../modules/mssql-server"

  application = "gresc"
  workload    = "logistics"
  environment = "prod"
  instance    = 1

  resource_group_name = "rg-gresc-prod"
  location            = "westeurope"

  # Prefer Azure AD-only authentication in production.
  # If SQL authentication is required, supply these securely
  # through a secret variable or pipeline secret.
  administrator_login          = var.sql_admin_login
  administrator_login_password = var.sql_admin_password

  minimum_tls_version = "1.2"
  connection_policy   = "Redirect"

  public_network_access_enabled        = false
  outbound_network_restriction_enabled = true

  managed_identity_type = "UserAssigned"

  managed_identity_ids = [
    var.sql_managed_identity_id
  ]

  primary_user_assigned_identity_id = var.sql_managed_identity_id

  azuread_administrator = {
    login_username              = var.azuread_admin_login
    object_id                   = var.azuread_admin_object_id
    tenant_id                   = var.tenant_id
    azuread_authentication_only = true
  }

  # Supply the versioned Key Vault key ID.
  transparent_data_encryption_key_vault_key_id = var.tde_key_id

  express_vulnerability_assessment_enabled = true

  databases = {
    logistics = {
      sku_name                    = "GP_Gen5_4"
      max_size_gb                 = 100
      collation                   = "SQL_Latin1_General_CP1_CI_AS"
      license_type                = "LicenseIncluded"
      zone_redundant              = true
      read_scale                  = false
      auto_pause_delay_in_minutes = -1
      prevent_destroy             = true
    }
  }

  private_endpoint_enabled = true

  private_endpoint_subnet_id = var.private_endpoint_subnet_id

  private_dns_zone_ids = [
    var.private_dns_zone_id
  ]

  tags = {
    owner              = "GRESC"
    cost_center        = "CHANGE-ME"
    criticality        = "high"
    data_classification = "confidential"
  }
}

output "sql_server_name" {
  value = module.mssql_server.server_name
}

output "sql_server_fqdn" {
  value = module.mssql_server.fully_qualified_domain_name
}

output "database_names" {
  value = module.mssql_server.database_names
}
