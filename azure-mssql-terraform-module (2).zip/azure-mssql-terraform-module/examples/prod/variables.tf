variable "sql_admin_login" {
  type        = string
  description = "SQL administrator login."
  default     = null
}

variable "sql_admin_password" {
  type        = string
  description = "SQL administrator password."
  sensitive   = true
  default     = null
}

variable "sql_managed_identity_id" {
  type        = string
  description = "User-assigned managed identity resource ID."
}

variable "azuread_admin_login" {
  type        = string
  description = "Microsoft Entra administrator login/group name."
}

variable "azuread_admin_object_id" {
  type        = string
  description = "Microsoft Entra administrator object ID."
}

variable "tenant_id" {
  type        = string
  description = "Microsoft Entra tenant ID."
}

variable "tde_key_id" {
  type        = string
  description = "Versioned Key Vault key ID for TDE CMK."
}

variable "private_endpoint_subnet_id" {
  type        = string
  description = "Subnet resource ID for the SQL Private Endpoint."
}

variable "private_dns_zone_id" {
  type        = string
  description = "Private DNS zone resource ID for privatelink.database.windows.net."
}
